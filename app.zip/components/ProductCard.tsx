"use client";

import { Product } from "@/types";
import { ShoppingCart, Star } from "lucide-react";
import { useCartStore } from "@/store";

export default function ProductCard({ product }: { product: Product }) {
  const addItem = useCartStore((s) => s.addItem);

  return (
    <div
      className="card-glow rounded-2xl overflow-hidden transition-all duration-200 group"
      style={{ background: "var(--color-surface)", border: "1px solid var(--color-border)" }}
    >
      {/* Image */}
      <div className="h-48 overflow-hidden relative" style={{ background: "var(--color-surface-2)" }}>
        {product.images?.[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.images[0]}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <ShoppingCart size={32} style={{ color: "var(--color-text-muted)" }} />
          </div>
        )}
        <div
          className="absolute top-3 left-3 px-2 py-0.5 rounded-full text-xs font-medium capitalize"
          style={{ background: "var(--color-surface-2)", color: "var(--color-text-muted)", border: "1px solid var(--color-border)" }}
        >
          {product.category}
        </div>
      </div>

      {/* Info */}
      <div className="p-4">
        <h3 className="font-semibold text-sm leading-snug mb-1" style={{ color: "var(--color-text)" }}>
          {product.name}
        </h3>
        <p className="text-xs line-clamp-2 mb-3" style={{ color: "var(--color-text-muted)" }}>
          {product.description}
        </p>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-3">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              size={11}
              style={{ color: i < Math.round(product.rating) ? "#f59e0b" : "var(--color-border)" }}
              fill={i < Math.round(product.rating) ? "#f59e0b" : "none"}
            />
          ))}
          <span className="text-xs ml-1" style={{ color: "var(--color-text-muted)" }}>({product.reviews})</span>
        </div>

        <div className="flex items-center justify-between">
          <span
            className="text-base font-semibold"
            style={{ color: "var(--color-accent)", fontFamily: "var(--font-mono)" }}
          >
            ₹{product.price.toLocaleString("en-IN")}
          </span>

          <button
            onClick={() => addItem(product)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all hover:scale-105 active:scale-95"
            style={{ background: "var(--color-accent)", color: "var(--color-bg)" }}
          >
            <ShoppingCart size={13} />
            Add
          </button>
        </div>
      </div>
    </div>
  );
}
