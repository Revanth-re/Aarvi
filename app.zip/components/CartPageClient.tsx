"use client";

import { useCartStore } from "@/store";
import Link from "next/link";
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft, ArrowRight } from "lucide-react";

export default function CartPageClient() {
  const { items, removeItem, updateQty, total, clearCart } = useCartStore();

  if (items.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-6 py-20 text-center">
        <div
          className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6"
          style={{ background: "var(--color-surface-2)" }}
        >
          <ShoppingBag size={28} style={{ color: "var(--color-text-muted)" }} />
        </div>
        <h2 className="text-2xl font-semibold mb-3" style={{ fontFamily: "var(--font-display)", color: "var(--color-text)", fontSize: "1.8rem" }}>
          Your cart is empty
        </h2>
        <p className="text-sm mb-8" style={{ color: "var(--color-text-muted)" }}>
          Explore our shop and find something you love.
        </p>
        <Link
          href="/shop"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-medium"
          style={{ background: "var(--color-accent)", color: "var(--color-bg)" }}
        >
          <ShoppingBag size={15} />
          Go to Shop
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <Link
        href="/shop"
        className="inline-flex items-center gap-1.5 text-sm mb-6"
        style={{ color: "var(--color-text-muted)" }}
      >
        <ArrowLeft size={14} />
        Continue shopping
      </Link>

      <h1
        className="text-3xl font-semibold mb-8"
        style={{ fontFamily: "var(--font-display)", color: "var(--color-text)", fontSize: "2rem" }}
      >
        Shopping Cart
        <span className="text-lg ml-3 font-normal" style={{ color: "var(--color-text-muted)" }}>
          ({items.reduce((a, i) => a + i.quantity, 0)} items)
        </span>
      </h1>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Items */}
        <div className="flex-1 space-y-3">
          {items.map(({ product, quantity }) => (
            <div
              key={product._id}
              className="flex gap-4 p-4 rounded-2xl"
              style={{ background: "var(--color-surface)", border: "1px solid var(--color-border)" }}
            >
              <div className="w-20 h-20 rounded-xl overflow-hidden flex-shrink-0" style={{ background: "var(--color-surface-2)" }}>
                {product.images?.[0] && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
                )}
              </div>

              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-sm mb-1 truncate" style={{ color: "var(--color-text)" }}>
                  {product.name}
                </h3>
                <p className="text-xs capitalize mb-3" style={{ color: "var(--color-text-muted)" }}>
                  {product.category}
                </p>

                <div className="flex items-center justify-between">
                  {/* Qty controls */}
                  <div
                    className="flex items-center rounded-lg overflow-hidden"
                    style={{ border: "1px solid var(--color-border)" }}
                  >
                    <button
                      onClick={() => updateQty(product._id, quantity - 1)}
                      className="w-8 h-8 flex items-center justify-center transition-colors hover:bg-[var(--color-surface-2)]"
                      style={{ color: "var(--color-text-muted)" }}
                    >
                      <Minus size={12} />
                    </button>
                    <span
                      className="w-8 h-8 flex items-center justify-center text-sm font-medium"
                      style={{ color: "var(--color-text)", fontFamily: "var(--font-mono)" }}
                    >
                      {quantity}
                    </span>
                    <button
                      onClick={() => updateQty(product._id, quantity + 1)}
                      className="w-8 h-8 flex items-center justify-center transition-colors hover:bg-[var(--color-surface-2)]"
                      style={{ color: "var(--color-text-muted)" }}
                    >
                      <Plus size={12} />
                    </button>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="font-semibold text-sm" style={{ color: "var(--color-accent)", fontFamily: "var(--font-mono)" }}>
                      ₹{(product.price * quantity).toLocaleString("en-IN")}
                    </span>
                    <button
                      onClick={() => removeItem(product._id)}
                      className="p-1.5 rounded-lg transition-colors hover:bg-red-500/10"
                      style={{ color: "var(--color-text-muted)" }}
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          <button
            onClick={clearCart}
            className="text-xs transition-colors hover:opacity-70"
            style={{ color: "var(--color-text-muted)" }}
          >
            Clear all items
          </button>
        </div>

        {/* Summary */}
        <div className="lg:w-80">
          <div
            className="p-6 rounded-2xl sticky top-20"
            style={{ background: "var(--color-surface)", border: "1px solid var(--color-border)" }}
          >
            <h3 className="font-semibold mb-6" style={{ color: "var(--color-text)" }}>Order Summary</h3>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-sm" style={{ color: "var(--color-text-muted)" }}>
                <span>Subtotal</span>
                <span style={{ fontFamily: "var(--font-mono)" }}>₹{total().toLocaleString("en-IN")}</span>
              </div>
              <div className="flex justify-between text-sm" style={{ color: "var(--color-text-muted)" }}>
                <span>Shipping</span>
                <span>{total() > 999 ? <span style={{ color: "var(--color-accent)" }}>Free</span> : "₹99"}</span>
              </div>
              <div
                className="pt-3 border-t flex justify-between font-semibold"
                style={{ borderColor: "var(--color-border)", color: "var(--color-text)" }}
              >
                <span>Total</span>
                <span style={{ fontFamily: "var(--font-mono)", color: "var(--color-accent)", fontSize: "1.1rem" }}>
                  ₹{(total() + (total() > 999 ? 0 : 99)).toLocaleString("en-IN")}
                </span>
              </div>
            </div>

            {total() <= 999 && (
              <p className="text-xs mb-4 p-2 rounded-lg" style={{ background: "var(--color-surface-2)", color: "var(--color-text-muted)" }}>
                Add ₹{(999 - total() + 1).toLocaleString("en-IN")} more for free shipping
              </p>
            )}

            <button
              className="w-full py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
              style={{ background: "var(--color-accent)", color: "var(--color-bg)" }}
            >
              Proceed to Checkout
              <ArrowRight size={15} />
            </button>

            <p className="text-xs text-center mt-3" style={{ color: "var(--color-text-muted)" }}>
              Secure checkout · Free returns
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
