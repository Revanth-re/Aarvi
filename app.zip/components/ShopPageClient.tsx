"use client";

import { useEffect, useState, useCallback } from "react";
import { Product } from "@/types";
import ProductCard from "@/components/ProductCard";
import { Search, X } from "lucide-react";

const CATEGORIES = ["all", "accessories", "clothing", "handicrafts", "merchandise"];

export default function ShopPageClient() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");

  const fetch_ = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (category !== "all") params.set("category", category);
      if (search) params.set("search", search);
      const res = await fetch(`/api/products?${params}`);
      const data = await res.json();
      if (Array.isArray(data)) setProducts(data);
    } finally {
      setLoading(false);
    }
  }, [category, search]);

  useEffect(() => {
    const t = setTimeout(fetch_, 300);
    return () => clearTimeout(t);
  }, [fetch_]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1
          className="text-3xl font-semibold mb-2"
          style={{ fontFamily: "var(--font-display)", color: "var(--color-text)", fontSize: "2.2rem" }}
        >
          The Shop
        </h1>
        <p className="text-sm" style={{ color: "var(--color-text-muted)" }}>
          Accessories, clothing, handicrafts & merchandise inspired by your favourite series
        </p>
      </div>

      {/* Search */}
      <div className="relative mb-6 max-w-lg">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: "var(--color-text-muted)" }} />
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-10 pr-10 py-2.5 rounded-xl text-sm outline-none"
          style={{ background: "var(--color-surface)", border: "1px solid var(--color-border)", color: "var(--color-text)" }}
        />
        {search && (
          <button className="absolute right-3 top-1/2 -translate-y-1/2" onClick={() => setSearch("")}>
            <X size={14} style={{ color: "var(--color-text-muted)" }} />
          </button>
        )}
      </div>

      {/* Category filters */}
      <div className="flex flex-wrap gap-2 mb-8">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategory(cat)}
            className="px-4 py-1.5 rounded-full text-sm capitalize transition-all"
            style={{
              background: category === cat ? "var(--color-accent)" : "var(--color-surface)",
              color: category === cat ? "var(--color-bg)" : "var(--color-text-muted)",
              border: `1px solid ${category === cat ? "var(--color-accent)" : "var(--color-border)"}`,
              fontWeight: category === cat ? 500 : 400,
            }}
          >
            {cat === "all" ? "All" : cat}
          </button>
        ))}
      </div>

      {/* Product count */}
      <p className="text-xs mb-6" style={{ color: "var(--color-text-muted)" }}>
        {loading ? "Loading..." : `${products.length} product${products.length !== 1 ? "s" : ""}`}
      </p>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {[...Array(8)].map((_, i) => <div key={i} className="skeleton rounded-2xl h-72" />)}
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-20">
          <p style={{ color: "var(--color-text-muted)" }}>No products found.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map((p) => <ProductCard key={p._id} product={p} />)}
        </div>
      )}
    </div>
  );
}
