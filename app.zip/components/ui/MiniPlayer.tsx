"use client";
import { useRef, useEffect, useState } from "react";
import Link from "next/link";
import { usePlayer } from "@/store";
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, X } from "lucide-react";

function fmt(s: number) { const m = Math.floor(s / 60); return `${m}:${String(Math.floor(s % 60)).padStart(2, "0")}`; }

const RATES = [0.75, 1, 1.25, 1.5, 2];

export default function MiniPlayer() {
  const { ep, series, playing, progress, duration, volume, rate, setPlaying, setProgress, setDuration, setVolume, setRate, next, prev } = usePlayer();
  const ref = useRef<HTMLAudioElement>(null);
  const [muted, setMuted] = useState(false);
  const [rIdx, setRIdx] = useState(1);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => { if (ep) setDismissed(false); }, [ep?._id]);
  useEffect(() => { if (!ref.current || !ep) return; ref.current.src = ep.audioUrl; ref.current.load(); if (playing) ref.current.play().catch(() => {}); }, [ep?._id]);
  useEffect(() => { if (!ref.current) return; playing ? ref.current.play().catch(() => {}) : ref.current.pause(); }, [playing]);
  useEffect(() => { if (ref.current) ref.current.volume = muted ? 0 : volume; }, [volume, muted]);
  useEffect(() => { if (ref.current) ref.current.playbackRate = rate; }, [rate]);

  if (!ep || dismissed) return null;
  const pct = duration > 0 ? (progress / duration) * 100 : 0;

  return (
    <>
      <audio ref={ref}
        onTimeUpdate={() => ref.current && setProgress(ref.current.currentTime)}
        onLoadedMetadata={() => ref.current && setDuration(ref.current.duration)}
        onEnded={next} preload="metadata"/>

      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0, zIndex: 100,
        background: "var(--surface)", borderTop: "1px solid var(--border2)",
        boxShadow: "0 -4px 30px rgba(0,0,0,.3)",
      }}>
        {/* Progress track */}
        <div style={{ height: 2, background: "var(--border)", cursor: "pointer", position: "relative" }}
          onClick={e => { const r = e.currentTarget.getBoundingClientRect(); const t = ((e.clientX - r.left) / r.width) * duration; setProgress(t); if (ref.current) ref.current.currentTime = t; }}>
          <div style={{ height: "100%", background: "linear-gradient(90deg,var(--accent),var(--accent2))", width: `${pct}%`, transition: "width .15s" }}/>
        </div>

        <div className="container" style={{ height: 68, display: "flex", alignItems: "center", gap: 12 }}>
          {/* Art + info */}
          <Link href={series ? `/series/${series._id}` : "#"} style={{ display: "flex", alignItems: "center", gap: 11, flex: 1, minWidth: 0, textDecoration: "none" }}>
            <div style={{ width: 42, height: 42, borderRadius: 8, overflow: "hidden", background: "var(--surface2)", flexShrink: 0, position: "relative" }}>
              {series?.coverImage && <img src={series.coverImage} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }}/>}
              {playing && (
                <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,.5)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <div className="eq"><span style={{height:8}}/><span/><span/><span style={{height:10}}/></div>
                </div>
              )}
            </div>
            <div style={{ minWidth: 0 }}>
              <p style={{ fontSize: 13, fontWeight: 600, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{ep.title}</p>
              <p style={{ fontSize: 11, color: "var(--text3)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{series?.title} · Ep {ep.episodeNumber}</p>
            </div>
          </Link>

          {/* Controls */}
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <button onClick={prev} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text3)", padding: 8, display: "flex", borderRadius: 8 }}><SkipBack size={17}/></button>
            <button onClick={() => setPlaying(!playing)} style={{ width: 40, height: 40, borderRadius: "50%", background: "var(--accent)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, boxShadow: "0 0 16px var(--accent)44" }}>
              {playing ? <Pause size={16} color="#fff" fill="#fff"/> : <Play size={16} color="#fff" fill="#fff" style={{ marginLeft: 2 }}/>}
            </button>
            <button onClick={next} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text3)", padding: 8, display: "flex", borderRadius: 8 }}><SkipForward size={17}/></button>
          </div>

          {/* Time */}
          <span className="hide-mobile" style={{ fontFamily: "var(--ff-mono)", fontSize: 11, color: "var(--text3)", whiteSpace: "nowrap" }}>
            {fmt(progress)} / {fmt(duration)}
          </span>

          {/* Speed */}
          <button className="hide-mobile" onClick={() => { const n = (rIdx + 1) % RATES.length; setRIdx(n); setRate(RATES[n]); }}
            style={{ padding: "4px 9px", borderRadius: 6, background: RATES[rIdx] !== 1 ? "var(--accent)" : "var(--surface2)", color: RATES[rIdx] !== 1 ? "#fff" : "var(--text3)", border: "none", cursor: "pointer", fontSize: 12, fontFamily: "var(--ff-mono)", fontWeight: 500 }}>
            {RATES[rIdx]}×
          </button>

          {/* Volume */}
          <div className="hide-mobile" style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <button onClick={() => setMuted(!muted)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text3)", display: "flex" }}>
              {muted ? <VolumeX size={16}/> : <Volume2 size={16}/>}
            </button>
            <div style={{ width: 72 }}><input type="range" min={0} max={1} step={.05} value={muted ? 0 : volume} onChange={e => setVolume(+e.target.value)}/></div>
          </div>

          {/* Dismiss */}
          <button onClick={() => { setPlaying(false); setDismissed(true); }} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text3)", display: "flex", padding: 8 }}>
            <X size={16}/>
          </button>
        </div>
      </div>
    </>
  );
}
