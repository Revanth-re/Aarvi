"use client";
import { Product } from "@/types";
import { ShoppingCart, Star, Check } from "lucide-react";
import { useCart } from "@/store";
import { useState } from "react";

export default function ProductCard({ p }: { p: Product }) {
  const add = useCart(s => s.add);
  const [added, setAdded] = useState(false);
  const handleAdd = () => { add(p); setAdded(true); setTimeout(() => setAdded(false), 1800); };

  return (
    <article className="card card-hover" style={{ overflow: "hidden", display: "flex", flexDirection: "column", minWidth: 0 }}>
      {/* Image */}
      <div style={{ position: "relative", paddingBottom: "75%", overflow: "hidden", background: "var(--surface2)", flexShrink: 0 }}>
        {p.images?.[0] && <img src={p.images[0]} alt={p.name} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", transition: "transform .4s" }}
          onMouseEnter={e => (e.currentTarget.style.transform = "scale(1.05)")}
          onMouseLeave={e => (e.currentTarget.style.transform = "")}/>}
        <div style={{ position: "absolute", top: 6, left: 6 }}>
          <span className="badge badge-muted" style={{ textTransform: "capitalize", fontSize: 9, padding: "2px 5px" }}>{p.category}</span>
        </div>
      </div>

      {/* Info */}
      <div style={{ padding: "8px 10px 10px", flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        <h3 style={{ fontSize: 12, fontWeight: 600, color: "var(--text)", marginBottom: 4, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" as const, overflow: "hidden", lineHeight: 1.4 }}>{p.name}</h3>

        {/* Stars */}
        <div style={{ display: "flex", alignItems: "center", gap: 1, marginBottom: 8, flexWrap: "nowrap" }}>
          {[1,2,3,4,5].map(i => <Star key={i} size={9} color={i<=Math.round(p.rating)?"#f59e0b":"var(--border2)"} fill={i<=Math.round(p.rating)?"#f59e0b":"none"}/>)}
          <span style={{ fontSize: 10, color: "var(--text3)", marginLeft: 3, whiteSpace: "nowrap" }}>({p.reviews})</span>
        </div>

        {/* Price + button */}
        <div style={{ marginTop: "auto", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 6, flexWrap: "wrap" }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: "var(--text)", fontFamily: "var(--ff-mono)", flexShrink: 0 }}>₹{p.price.toLocaleString("en-IN")}</span>
          <button onClick={handleAdd}
            style={{ display: "flex", alignItems: "center", gap: 4, padding: "5px 10px", borderRadius: 7, border: "none", cursor: "pointer", fontSize: 11, fontWeight: 600, transition: "all .2s", background: added ? "var(--success)" : "var(--accent)", color: "#fff", flexShrink: 0, whiteSpace: "nowrap" }}>
            {added ? <><Check size={11}/>Added</> : <><ShoppingCart size={11}/>Add</>}
          </button>
        </div>
      </div>
    </article>
  );
}
