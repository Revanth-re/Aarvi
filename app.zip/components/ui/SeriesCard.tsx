"use client";
import Link from "next/link";
import { Series } from "@/types";
import { Play, Heart, Star, Clock } from "lucide-react";
import { useApp } from "@/store";

export default function SeriesCard({ s }: { s: Series }) {
  const { liked, toggleLike } = useApp();
  const isLiked = liked.includes(s._id);
  const fmtPlays = (n: number) => n >= 1e6 ? `${(n/1e6).toFixed(1)}M` : n >= 1e3 ? `${(n/1e3).toFixed(0)}K` : String(n);

  return (
    <Link href={`/series/${s._id}`} style={{ textDecoration: "none", display: "block", width: "100%", minWidth: 0 }}>
      <article className="card card-hover series-card" style={{ overflow: "hidden", height: "100%", width: "100%" }}>
        {/* Cover */}
        <div style={{ position: "relative", paddingBottom: "62%", overflow: "hidden", background: "var(--surface2)" }}>
          {s.coverImage && (
            <img src={s.coverImage} alt={s.title} style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover", transition: "transform .4s" }}
              onMouseEnter={e => (e.currentTarget.style.transform = "scale(1.05)")}
              onMouseLeave={e => (e.currentTarget.style.transform = "")}/>
          )}
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, rgba(0,0,0,.75) 0%, transparent 55%)" }}/>

          {/* Badge */}
          <div style={{ position: "absolute", top: 6, left: 6, display: "flex", gap: 3, maxWidth: "65%" }}>
            <span className="badge badge-accent sc-badge">{s.genre}</span>
            {s.isTrending && <span className="badge badge-accent2 sc-badge">🔥</span>}
          </div>

          {/* Like */}
          <button onClick={e => { e.preventDefault(); toggleLike(s._id); }}
            style={{ position: "absolute", top: 6, right: 6, width: 26, height: 26, borderRadius: "50%", background: "rgba(0,0,0,.5)", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: isLiked ? "var(--accent2)" : "#fff", backdropFilter: "blur(4px)", flexShrink: 0 }}>
            <Heart size={12} fill={isLiked ? "currentColor" : "none"}/>
          </button>

          {/* Play overlay */}
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", opacity: 0, transition: "opacity .2s" }} className="play-ov">
            <div style={{ width: 40, height: 40, borderRadius: "50%", background: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 4px 20px rgba(0,0,0,.5)" }}>
              <Play size={16} color="#fff" fill="#fff" style={{ marginLeft: 2 }}/>
            </div>
          </div>
        </div>

        {/* Info */}
        <div style={{ padding: "8px 10px 10px", minWidth: 0 }}>
          <h3 style={{ fontSize: 12, fontWeight: 600, color: "var(--text)", marginBottom: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", lineHeight: 1.3 }}>{s.title}</h3>
          <p style={{ fontSize: 10, color: "var(--text3)", marginBottom: 6, display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" as const, overflow: "hidden", lineHeight: 1.4 }}>{s.description}</p>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", fontSize: 10, gap: 4, flexWrap: "wrap" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ display: "flex", alignItems: "center", gap: 2, color: "var(--text3)" }}>
                <Star size={9} color="#f59e0b" fill="#f59e0b"/>{s.rating}
              </span>
              <span style={{ display: "flex", alignItems: "center", gap: 2, color: "var(--text3)" }}>
                <Clock size={9}/>{s.totalEpisodes}ep
              </span>
            </div>
            <span style={{ color: "var(--text3)", flexShrink: 0 }}>{fmtPlays(s.totalPlays)}</span>
          </div>
        </div>
      </article>
      <style>{`
        .card:hover .play-ov { opacity: 1 !important; }
        .sc-badge { font-size: 9px !important; padding: 2px 5px !important; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 70px; }
      `}</style>
    </Link>
  );
}
