"use client";

import { useEffect } from "react";
import { useAppStore } from "@/store";
import Navbar from "@/components/Navbar";
import MiniPlayer from "@/components/MiniPlayer";

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const theme = useAppStore((s) => s.theme);

  // Sync data-theme attribute whenever theme changes
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  return (
    <>
      <Navbar />
      <main style={{ paddingBottom: "96px", minHeight: "100vh" }}>
        {children}
      </main>
      <MiniPlayer />
    </>
  );
}
