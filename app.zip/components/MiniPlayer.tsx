"use client";

import { useRef, useEffect, useState } from "react";
import Link from "next/link";
import { usePlayerStore } from "@/store";
import {
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX,
  ChevronUp, FileText, Gauge
} from "lucide-react";

function formatTime(secs: number) {
  const m = Math.floor(secs / 60);
  const s = Math.floor(secs % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

const RATES = [0.75, 1, 1.25, 1.5, 1.75, 2];

export default function MiniPlayer() {
  const {
    currentEpisode, currentSeries, isPlaying, progress, duration,
    volume, playbackRate, setPlaying, setProgress, setDuration, setVolume,
    setPlaybackRate, playNext, playPrev,
  } = usePlayerStore();

  const audioRef = useRef<HTMLAudioElement>(null);
  const [muted, setMuted] = useState(false);
  const [rateIdx, setRateIdx] = useState(1);

  useEffect(() => {
    if (!audioRef.current || !currentEpisode) return;
    audioRef.current.src = currentEpisode.audioUrl;
    audioRef.current.load();
    if (isPlaying) audioRef.current.play().catch(() => {});
  }, [currentEpisode]);

  useEffect(() => {
    if (!audioRef.current) return;
    if (isPlaying) audioRef.current.play().catch(() => {});
    else audioRef.current.pause();
  }, [isPlaying]);

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = muted ? 0 : volume;
  }, [volume, muted]);

  useEffect(() => {
    if (audioRef.current) audioRef.current.playbackRate = playbackRate;
  }, [playbackRate]);

  if (!currentEpisode) return null;

  const progressPct = duration > 0 ? (progress / duration) * 100 : 0;

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setProgress(val);
    if (audioRef.current) audioRef.current.currentTime = val;
  };

  const cycleRate = () => {
    const next = (rateIdx + 1) % RATES.length;
    setRateIdx(next);
    setPlaybackRate(RATES[next]);
  };

  return (
    <>
      <audio
        ref={audioRef}
        onTimeUpdate={() => { if (audioRef.current) setProgress(audioRef.current.currentTime); }}
        onLoadedMetadata={() => { if (audioRef.current) setDuration(audioRef.current.duration); }}
        onEnded={playNext}
        preload="metadata"
      />
      <div
        className="fixed bottom-0 left-0 right-0 z-50 glass"
        style={{ borderTop: "1px solid var(--color-border)" }}
      >
        {/* Progress bar */}
        <div className="relative h-1 w-full" style={{ background: "var(--color-border)" }}>
          <div
            className="absolute top-0 left-0 h-full transition-all"
            style={{ width: `${progressPct}%`, background: "var(--color-accent)" }}
          />
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={1}
            value={progress}
            onChange={handleSeek}
            className="absolute inset-0 w-full opacity-0 cursor-pointer h-full"
          />
        </div>

        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center gap-4">
          {/* Cover + title */}
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <div
              className="w-10 h-10 rounded-lg overflow-hidden flex-shrink-0 relative"
              style={{ background: "var(--color-surface-2)" }}
            >
              {currentSeries?.coverImage && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={currentSeries.coverImage} alt="" className="w-full h-full object-cover" />
              )}
              {isPlaying && (
                <div className="absolute inset-0 flex items-end justify-center gap-0.5 pb-1">
                  {[1,2,3,4].map(i => (
                    <div key={i} className="equalizer-bar" style={{ height: `${8 + i * 2}px` }} />
                  ))}
                </div>
              )}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium truncate" style={{ color: "var(--color-text)" }}>
                {currentEpisode.title}
              </p>
              <p className="text-xs truncate" style={{ color: "var(--color-text-muted)" }}>
                {currentSeries?.title} · Ep {currentEpisode.episodeNumber}
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button onClick={playPrev} className="p-1.5" style={{ color: "var(--color-text-muted)" }}>
              <SkipBack size={18} />
            </button>
            <button
              onClick={() => setPlaying(!isPlaying)}
              className="w-9 h-9 rounded-full flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
              style={{ background: "var(--color-accent)" }}
            >
              {isPlaying
                ? <Pause size={16} style={{ color: "var(--color-bg)" }} fill="currentColor" />
                : <Play size={16} style={{ color: "var(--color-bg)" }} fill="currentColor" />
              }
            </button>
            <button onClick={playNext} className="p-1.5" style={{ color: "var(--color-text-muted)" }}>
              <SkipForward size={18} />
            </button>
          </div>

          {/* Time */}
          <div className="hidden sm:flex items-center gap-1 text-xs" style={{ color: "var(--color-text-muted)", fontFamily: "var(--font-mono)" }}>
            <span>{formatTime(progress)}</span>
            <span>/</span>
            <span>{formatTime(duration)}</span>
          </div>

          {/* Right controls */}
          <div className="hidden md:flex items-center gap-2">
            <button
              onClick={cycleRate}
              className="px-2 py-1 rounded text-xs font-medium transition-colors"
              style={{
                background: RATES[rateIdx] !== 1 ? "var(--color-accent)" : "var(--color-surface-2)",
                color: RATES[rateIdx] !== 1 ? "var(--color-bg)" : "var(--color-text-muted)",
                fontFamily: "var(--font-mono)"
              }}
            >
              {RATES[rateIdx]}×
            </button>

            <button
              onClick={() => setMuted(!muted)}
              className="p-1.5"
              style={{ color: "var(--color-text-muted)" }}
            >
              {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            </button>

            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={muted ? 0 : volume}
              onChange={e => setVolume(parseFloat(e.target.value))}
              className="w-20"
              style={{ accentColor: "var(--color-accent)" }}
            />
          </div>

          {currentSeries && (
            <Link
              href={`/series/${currentSeries._id}`}
              className="hidden sm:flex p-1.5 rounded"
              style={{ color: "var(--color-text-muted)" }}
              title="Go to series"
            >
              <ChevronUp size={16} />
            </Link>
          )}
        </div>
      </div>
    </>
  );
}
